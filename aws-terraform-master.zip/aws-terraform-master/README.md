# az-devops-terraform
automating az devops using terraform
